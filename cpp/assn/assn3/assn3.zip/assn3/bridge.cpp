
#include "bridge.h"
#include "constants.h"
#include "bridge.h"

Bridge :: Bridge(int input_num, int output_num) {
    // TODO

}

double* Bridge :: forward(double* input) {
    // TODO

    
}