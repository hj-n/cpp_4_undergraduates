
#ifndef HELPER_CPP
#define HELPER_CPP

void random_init();
double rand_weight_generator();

#endif