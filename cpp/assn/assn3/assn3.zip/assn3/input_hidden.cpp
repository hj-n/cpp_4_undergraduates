#include "input_hidden.h"

void Input_Hidden :: backprop(double* delta) {
    // TODO


    delete[] delta;  // free dynamic allocation 
}